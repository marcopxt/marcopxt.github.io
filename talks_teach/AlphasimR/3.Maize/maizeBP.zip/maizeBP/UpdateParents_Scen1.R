#Sets new parents for inbreds

# Male heterotic group
MaleParents = selectInd(c(MaleInbredYT4,MaleInbredYT3),nParents)

# Female heterotic group
FemaleParents = selectInd(c(FemaleInbredYT4,FemaleInbredYT3),nParents)
