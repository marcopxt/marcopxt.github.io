#Sets new parents for inbreds

# Male heterotic group
MaleParents = selectInd(MaleYT2,nParents)

# Female heterotic group
FemaleParents = selectInd(FemaleYT2,nParents)

